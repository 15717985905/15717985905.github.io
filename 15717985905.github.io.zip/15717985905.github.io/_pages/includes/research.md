
# 🔍 Research Projects
<div class='paper-box'><div class='paper-box-image'><div><div class="badge">Simple</div><img src='../../images/publication1.png' alt="sym" width="100%"></div></div>
<div class='paper-box-text' markdown="1">

[project name](https://project.name.com) | 2023.10 – Present
- Presented at American Psychological Association 2024 Convention.
- Explored 5 different personality tests using OpenAI’s large, contextualized embeddings, suggesting new paradigm to analyze psychometric tests.
</div>
</div>
