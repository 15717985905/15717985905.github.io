# 🎖 Honors and Awards
## AWARDS
- 2023 and 2024 National Standardization Olympiad for College Students | Macau| Oct. 2024
  - The excellence prize, Team leader
  - FOOD QUIZ BOWL 2023| Guangzhou| June. 2023
  - Finalist (top 10), Team leader
- The first prize of 2022 International English Vocabulary Challenge for College Students | Macau | Oct. 2022

## Skills
- Lab skills: Analysis & Measurement, Infrared (IR) Ultraviolet (UV) spectrophotometers, High Performance Liquid Chromatography (HPLC), Liquid Nitrogen Freezer, Agarose gel electrophoresis, Microbiological culture
- Language: Mandarin, English
- Programming: Python (International Summer Session, Fudan University)
- Toolkits: Endnote, Zotero, SPSS, Graph prism, Photoshop, MATLAB, AutoDock