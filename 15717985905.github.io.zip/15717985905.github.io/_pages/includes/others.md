# 📖 Educations
- BNFS in Food Science And Nutrition Technology, 2022-2026
  -Macao University of Science and Technology, Macau
- Visiting student at the Institute of Chemical Biology，2024.09
  - Shenzhen Bay Laboratory, China
- Chemical Biology Summer Course，2024.06
  - Peking University, China
- International Summer Session, 2023.07
  - Fudan University, China

# 📖 Interests
- Nutrition and disease
- Food Science
- Biomedical science

# 📖 Internships
- 
